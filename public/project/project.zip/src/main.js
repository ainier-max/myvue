import { createApp } from 'vue'
import App from './App.vue'

window.vueApp=createApp(App);
import router from "./router/index";
window.vueApp.use(router).mount('#app');

