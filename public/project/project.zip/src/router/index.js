import { createRouter, createWebHashHistory, createWebHistory } from 'vue-router';
const routes = [
    {
        path: '/',
        component: () => import('../packageComponent/test.vue')
    },
    {
        path: '/test',
        component: () => import('../packageComponent/test.vue')
    }
];
const router = createRouter({
    history: createWebHashHistory(),  // hash路由模式
    // history: createWebHistory(),  // history路由模式
    routes
});
export default router;