//首尾行不可变动，便于组件上传至后端的操作。
let packUmdComponentConfig = {
  geojsonArr: [
    {
      name: "fujian",
      url: "http://127.0.0.1:8089/DependenciesPackage/geojson/fujian.json",
    },
  ],
  attr: {
    x: 120,
    y: 100,
    w: 400,
    h: 300,
    zIndex: 100,
    opacity: 1,
    unit: "px",
    show: true,
  },
  option: {
    title: {
      show: false,
      text: "福建",
      subtext: "福建人口密度",
    },
    tooltip: {
      trigger: "item",
      formatter: function anonymous(params) {
        return params.name + "" + params.value + "个 ";
      },
    },
    toolbox: {
      show: false,
      orient: "vertical",
      left: "right",
      top: "center",
      feature: {
        dataView: {
          readOnly: false,
        },
        restore: {},
        saveAsImage: {},
      },
    },
    visualMap: {
      min: 800,
      max: 60000,
      text: ["High", "Low"],
      realtime: false,
      calculable: true,
      inRange: {
        color: ["#1b83cd", "#228974", "#cf924f", "#ca4a50"],
      },
      textStyle: {
        color: "rgba(255,255,255,0.65)",
        fontSize: 14,
        fontFamily: "Microsoft YaHei",
      },
    },
    geo: {
      map: "fujian",
      aspectScale: 0.76,
      zoom: 1.005,
      label: {
        normal: {
          show: false,
        },
        emphasis: {
          show: true,
        },
      },
      roam: false,
      itemStyle: {
        normal: {
          areaColor: "#00FFFF",
          borderWidth: 4,
          shadowColor: "#0098d9",
          borderColor: "#00FFFF",
          shadowBlur: 12,
          shadowOffsetX: 0,
          shadowOffsetY: 12,
        },
        emphasis: {
          show: false,
        },
      },
    },
    series: [
      {
        name: "福建人口数量",
        type: "map",
        map: "fujian",
        roam: false,
        label: {
          show: true,
          color: "rgba(255,255,255,0.65)",
        },
      },
    ],
  },
  dataset: {
    dimensions: ["name"],
    metrics: ["value"],
    fields: ["name", "value"],
    data: [
      {
        name: "福州市",
        value: 20057,
      },
      {
        name: "厦门市",
        value: 15477,
      },
      {
        name: "泉州市",
        value: 40057,
      },
      {
        name: "漳州市",
        value: 35477,
      },
      {
        name: "龙岩市",
        value: 20557,
      },
      {
        name: "三明市",
        value: 25477,
      },
      {
        name: "南平市",
        value: 10057,
      },
      {
        name: "宁德市",
        value: 45477,
      },
      {
        name: "莆田市",
        value: 60000,
      }
    ],
  },
}

export default packUmdComponentConfig;
