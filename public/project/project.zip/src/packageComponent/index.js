import PackUmdComponent from "./code/index.vue";
import { component_id } from "../../bin/pack/config.js";

PackUmdComponent.install=(app)=>{
    app.component(component_id,PackUmdComponent);
};

export default PackUmdComponent;