<template>
  <div>
    <component :style="componentStyle" :is="component_id" v-if="showFlag" @event="eventFun" :component="component">
    </component>
  </div>
</template>

<script>
import EchartMap from './code/index.vue'
import packUmdComponentConfig from './config.js'

export default {
  data() {
    return {
      component_id:"EchartMap",
      component:{},
      componentStyle:null,
      showFlag:false,
    };
  },
  components:{
    EchartMap:EchartMap
  },
  watch: {},
  created() {
    console.log("packUmdComponentConfig",packUmdComponentConfig);
    this.component.component_config=packUmdComponentConfig;
  },
  mounted() {
    //组件基础样式设置
    this.getStyle(packUmdComponentConfig);
  },
  methods: {
    eventFun(eventType,obj,component){
      console.log("事件类型：",eventType);
      console.log("事件传递值：",obj);
      console.log("当前事件所属组件信息：",component);
    },
    //组件样式设置
    getStyle(component_config) {
      try {
        let attr = component_config.attr;
        let style = {
          position: "absolute",
          left: attr.x + attr.unit,
          top: attr.y + attr.unit,
          width: attr.w + attr.unit,
          height: attr.h + attr.unit,
          zIndex: attr.zIndex,
          opacity: attr.opacity
        };
        //console.log("style",style);
        this.componentStyle = style;
        this.$nextTick(()=> {
          this.showFlag=true;
        });
      }catch (e){
        console.log(e);
      }
    },
  },
};
</script>
