<template>
  <div style="width: 100%; height: 100%">
    <div id="echartID" style="width: 100%; height: 100%"></div>
  </div>
</template>

<script>
// 引入echarts
import * as echarts from "echarts";
import axios from "axios";

export default {
  props: {
    component: {
      type: Object,
      default() {
        return {};
      }
    }
  },
  data() {
    return {};
  },
  watch: {},
  created() {
    console.log("时间：20231108");
    console.log("created--componentConfig", this.component.config);
  },
  mounted() {
    if (typeof this.component.config.dataset == "undefined") {
      return;
    }

    if (
      this.component.config.dataset.dimensions.length == 0 ||
      this.component.config.dataset.metrics.length == 0
    ) {
      return;
    }

    let the = this;
    for (let i = 0; i < this.component.config.geojsonArr.length; i++) {
      axios.get(this.component.config.geojsonArr[i].url).then((res) => {
        echarts.registerMap(this.component.config.geojsonArr[i].name, res.data);
        the.setData();
      });
    }
  },

  methods: {
    setData() {
      const dimensions = this.component.config.dataset.dimensions;
      const metrics = this.component.config.dataset.metrics;
      const data = this.component.config.dataset.data;
      const option = this.component.config.option;
      option.series[0].data=[];
      for(let i=0;i<data.length;i++){
        let objTemp={};
        objTemp.name=data[i][dimensions[0]];
        objTemp.value=data[i][metrics[0]];
        option.series[0].data.push(objTemp);
      }
      console.log("setData:option",option);
      let chart = document.getElementById("echartID");
      //console.log("initEchartMap--chart1", chart);
      const myChart = echarts.init(chart);
      //console.log("initEchartMap--myChart1", myChart);
      myChart.setOption(this.component.config.option);
      window.addEventListener("resize", function () {
        myChart.resize();
      });
      this.setHandleEvent(myChart);
    },
    setHandleEvent(myChart) {
      myChart.on("click", this.handleEvent);
    },
    handleEvent(params) {
      var row = this.component.config.dataset.data[params.dataIndex];
      this.$emit("event", "click", row, this.component);
    },
  },
};
</script>
