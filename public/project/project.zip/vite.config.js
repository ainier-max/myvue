import {defineConfig} from 'vite'
import pluginVue from '@vitejs/plugin-vue'
import externalGlobals from 'rollup-plugin-external-globals';
import commonjs from '@rollup/plugin-commonjs';

export default defineConfig({
    plugins: [
        commonjs(),
        pluginVue()
    ],
    define:{
        'process.env':{}
    },
    build:{
        lib:{
            entry:'./src/packageComponent/index.js',
            name:'EchartMap'
        },
        rollupOptions: {
            // 确保外部化处理那些你不想打包进库的依赖['vue','echarts','axios'],
            external: ['vue','echarts','axios'],

            plugins: [
                externalGlobals({
                    vue: 'vue',
                    echarts:'echarts',
                    axios:'axios' 
                }),
            ],
        },
    },
    server:{
        host:"127.0.0.1",
        port:"4000",
    }
})